```python
import numpy as np
import pandas as pd
import matplotlib as plt
# make plots appear and be stored within the notebook
%matplotlib inline
```

# EX1 
## 1.1


```python
#read the data using pandas
Sig_Eqs=pd.read_csv("earthquakes-2022-10-26_18-25-54_+0800.tsv",delimiter="\t")
Sig_Eqs.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 6338 entries, 0 to 6337
    Data columns (total 48 columns):
     #   Column                              Non-Null Count  Dtype  
    ---  ------                              --------------  -----  
     0   Search Parameters                   1 non-null      object 
     1   Year                                6337 non-null   float64
     2   Mo                                  5926 non-null   float64
     3   Dy                                  5770 non-null   float64
     4   Hr                                  4286 non-null   float64
     5   Mn                                  4081 non-null   float64
     6   Sec                                 4424 non-null   float64
     7   Tsu                                 1952 non-null   float64
     8   Vol                                 77 non-null     float64
     9   Country                             6336 non-null   object 
     10  Area                                326 non-null    object 
     11  Region                              6337 non-null   float64
     12  Location Name                       6336 non-null   object 
     13  Latitude                            6285 non-null   float64
     14  Longitude                           6285 non-null   float64
     15  Focal Depth (km)                    3363 non-null   float64
     16  Mag                                 4559 non-null   float64
     17  Mw                                  1555 non-null   float64
     18  Ms                                  2985 non-null   float64
     19  Mb                                  1824 non-null   float64
     20  Ml                                  188 non-null    float64
     21  Mfa                                 14 non-null     float64
     22  Unk                                 795 non-null    float64
     23  MMI Int                             3019 non-null   float64
     24  Deaths                              2123 non-null   float64
     25  Death Description                   2607 non-null   float64
     26  Missing                             26 non-null     float64
     27  Missing Description                 26 non-null     float64
     28  Injuries                            1336 non-null   float64
     29  Injuries Description                1559 non-null   float64
     30  Damage ($Mil)                       541 non-null    float64
     31  Damage Description                  4583 non-null   float64
     32  Houses Destroyed                    847 non-null    float64
     33  Houses Destroyed Description        1828 non-null   float64
     34  Houses Damaged                      534 non-null    float64
     35  Houses Damaged Description          1049 non-null   float64
     36  Total Deaths                        1909 non-null   float64
     37  Total Death Description             2278 non-null   float64
     38  Total Missing                       29 non-null     float64
     39  Total Missing Description           33 non-null     float64
     40  Total Injuries                      1357 non-null   float64
     41  Total Injuries Description          1580 non-null   float64
     42  Total Damage ($Mil)                 514 non-null    float64
     43  Total Damage Description            3611 non-null   float64
     44  Total Houses Destroyed              879 non-null    float64
     45  Total Houses Destroyed Description  1910 non-null   float64
     46  Total Houses Damaged                478 non-null    float64
     47  Total Houses Damaged Description    940 non-null    float64
    dtypes: float64(44), object(4)
    memory usage: 2.3+ MB
    


```python
# compute the total death number and sort the index by the values
death_number=Sig_Eqs.groupby(["Country"]).sum()["Deaths"].sort_values(ascending=False)
# read the first 20 countries
death_number.head(20)
```




    Country
    CHINA           2075019.0
    TURKEY          1134569.0
    IRAN            1011446.0
    ITALY            498477.0
    SYRIA            439224.0
    HAITI            323474.0
    AZERBAIJAN       317219.0
    JAPAN            278142.0
    ARMENIA          191890.0
    PAKISTAN         145083.0
    IRAQ             136200.0
    ECUADOR          135479.0
    TURKMENISTAN     117412.0
    PERU             102219.0
    ISRAEL            90388.0
    PORTUGAL          83531.0
    GREECE            79174.0
    CHILE             64276.0
    INDIA             63491.0
    TAIWAN            57135.0
    Name: Deaths, dtype: float64



## 1.2



```python
earthquake_years=Sig_Eqs.loc[Sig_Eqs["Ms"]>3].groupby(["Year"])
earthquake_years["Ms"].count().plot(xlabel="Year",ylabel="earthquake with magnitude exceed 3 per year",figsize=(10, 6),color="green",kind="line")

```




    <AxesSubplot:xlabel='Year', ylabel='earthquake with magnitude exceed 3 per year'>




    
![png](output_5_1.png)
    


>the tread of the deaths in earthquake between -2000 to 1500 is almost stable, and it had a sharp increase between 1500-2000. I think the rapid multiplying of the population and assembling of houses are the main reason which caused this phenomenon.Besides,the recording may lose across the ages.

## 1.3


```python
death_number=Sig_Eqs.loc[:,["Country","Location Name","Ms"]]
death_number
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Location Name</th>
      <th>Ms</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>JORDAN</td>
      <td>JORDAN:  BAB-A-DARAA,AL-KARAK</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>SYRIA</td>
      <td>SYRIA:  UGARIT</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>TURKMENISTAN</td>
      <td>TURKMENISTAN:  W</td>
      <td>7.1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>GREECE</td>
      <td>GREECE:  THERA ISLAND (SANTORINI)</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>6333</th>
      <td>MEXICO</td>
      <td>MEXICO:  MICHOACAN, COLIMA, JALISCO</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>6334</th>
      <td>MEXICO</td>
      <td>MEXICO: MEXICO CITY, MICHOACAN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>6335</th>
      <td>INDONESIA</td>
      <td>INDONESIA:  SUMATRA</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>6336</th>
      <td>IRAN</td>
      <td>IRAN:  KHOY; WEST AZERBAIJAN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>6337</th>
      <td>PERU</td>
      <td>PERU:  PIURA</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>6338 rows × 3 columns</p>
</div>




```python
def CountEq_LargestEq():
    death_number[]
```


      Input In [7]
        death_number[]
                     ^
    SyntaxError: invalid syntax
    


# Ex2 air temperature in Shenzhen




```python
Air_temp=pd.read_csv("Baoan_Weather_1998_2022.csv")
Air_temp.info()

```

    C:\Users\Administrator\AppData\Local\Temp\ipykernel_20960\4145672413.py:1: DtypeWarning: Columns (4,8,9,10,11,14,15,24,25,27,29,31,34,37,38,40,41,45,49,50) have mixed types. Specify dtype option on import or set low_memory=False.
      Air_temp=pd.read_csv("Baoan_Weather_1998_2022.csv")
    

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 235674 entries, 0 to 235673
    Data columns (total 54 columns):
     #   Column             Non-Null Count   Dtype  
    ---  ------             --------------   -----  
     0   STATION            235674 non-null  int64  
     1   DATE               235674 non-null  object 
     2   SOURCE             235674 non-null  int64  
     3   REPORT_TYPE        235674 non-null  object 
     4   CALL_SIGN          235674 non-null  object 
     5   QUALITY_CONTROL    235674 non-null  object 
     6   AA1                24482 non-null   object 
     7   AA2                5923 non-null    object 
     8   AA3                3207 non-null    object 
     9   AG1                7307 non-null    object 
     10  AJ1                679 non-null     object 
     11  AW1                3 non-null       object 
     12  AY1                15557 non-null   object 
     13  AY2                9200 non-null    object 
     14  AZ1                3 non-null       object 
     15  CALL_SIGN.1        235674 non-null  object 
     16  CIG                235674 non-null  object 
     17  DEW                235674 non-null  object 
     18  ED1                1210 non-null    object 
     19  EQD                73120 non-null   object 
     20  GA1                132689 non-null  object 
     21  GA2                52828 non-null   object 
     22  GA3                10352 non-null   object 
     23  GA4                470 non-null     object 
     24  GA5                2 non-null       object 
     25  GE1                53148 non-null   object 
     26  GF1                176884 non-null  object 
     27  HL1                2 non-null       object 
     28  IA1                0 non-null       float64
     29  IA2                1791 non-null    object 
     30  KA1                19563 non-null   object 
     31  KA2                3713 non-null    object 
     32  MA1                216152 non-null  object 
     33  MD1                64222 non-null   object 
     34  ME1                2 non-null       object 
     35  MW1                106276 non-null  object 
     36  MW2                6146 non-null    object 
     37  MW3                213 non-null     object 
     38  OA1                47 non-null      object 
     39  OC1                3028 non-null    object 
     40  OD1                3777 non-null    object 
     41  OD2                1 non-null       object 
     42  QUALITY_CONTROL.1  235674 non-null  object 
     43  REM                235450 non-null  object 
     44  REPORT_TYPE.1      235674 non-null  object 
     45  SA1                4 non-null       object 
     46  SLP                235674 non-null  object 
     47  SOURCE.1           235674 non-null  int64  
     48  TMP                235674 non-null  object 
     49  UA1                4 non-null       object 
     50  UG1                4 non-null       object 
     51  VIS                235674 non-null  object 
     52  WG1                0 non-null       float64
     53  WND                235674 non-null  object 
    dtypes: float64(2), int64(3), object(49)
    memory usage: 97.1+ MB
    


```python
#first,we need to identify whether this is missing values by using count()
Air_temp.count()

```




    STATION              235674
    DATE                 235674
    SOURCE               235674
    REPORT_TYPE          235674
    CALL_SIGN            235674
    QUALITY_CONTROL      235674
    AA1                   24482
    AA2                    5923
    AA3                    3207
    AG1                    7307
    AJ1                     679
    AW1                       3
    AY1                   15557
    AY2                    9200
    AZ1                       3
    CALL_SIGN.1          235674
    CIG                  235674
    DEW                  235674
    ED1                    1210
    EQD                   73120
    GA1                  132689
    GA2                   52828
    GA3                   10352
    GA4                     470
    GA5                       2
    GE1                   53148
    GF1                  176884
    HL1                       2
    IA1                       0
    IA2                    1791
    KA1                   19563
    KA2                    3713
    MA1                  216152
    MD1                   64222
    ME1                       2
    MW1                  106276
    MW2                    6146
    MW3                     213
    OA1                      47
    OC1                    3028
    OD1                    3777
    OD2                       1
    QUALITY_CONTROL.1    235674
    REM                  235450
    REPORT_TYPE.1        235674
    SA1                       4
    SLP                  235674
    SOURCE.1             235674
    TMP                  235674
    UA1                       4
    UG1                       4
    VIS                  235674
    WG1                       0
    WND                  235674
    dtype: int64




```python
# detect if there are values=9999,which stands for missing
Air_temp.loc[Air_temp["TMP"]==9999].count()
#remove the missing data and convert the object form into float
Air_temp["tem"]=0.1*Air_temp["TMP"].apply(lambda x: x.replace("1+","").replace(",","")).astype("float")
Air_temp=Air_temp.loc[Air_temp["tem"]<500]

```


```python
# So we finally get temperature data
Air_temp["tem"].max()
Air_temp.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>STATION</th>
      <th>DATE</th>
      <th>SOURCE</th>
      <th>REPORT_TYPE</th>
      <th>CALL_SIGN</th>
      <th>QUALITY_CONTROL</th>
      <th>AA1</th>
      <th>AA2</th>
      <th>AA3</th>
      <th>AG1</th>
      <th>...</th>
      <th>SA1</th>
      <th>SLP</th>
      <th>SOURCE.1</th>
      <th>TMP</th>
      <th>UA1</th>
      <th>UG1</th>
      <th>VIS</th>
      <th>WG1</th>
      <th>WND</th>
      <th>tem</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>59493099999</td>
      <td>1998-01-01T00:00:00</td>
      <td>4</td>
      <td>SY-MT</td>
      <td>ZGSZ</td>
      <td>V020</td>
      <td>06,0000,9,1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0,000</td>
      <td>...</td>
      <td>NaN</td>
      <td>10184,1</td>
      <td>4</td>
      <td>+0186,1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>008000,1,N,1</td>
      <td>NaN</td>
      <td>040,1,N,0040,1</td>
      <td>186.1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>59493099999</td>
      <td>1998-01-01T01:00:00</td>
      <td>4</td>
      <td>FM-15</td>
      <td>ZGSZ</td>
      <td>V020</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0,999</td>
      <td>...</td>
      <td>NaN</td>
      <td>99999,9</td>
      <td>4</td>
      <td>+0220,1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>003300,1,N,1</td>
      <td>NaN</td>
      <td>130,1,N,0020,1</td>
      <td>220.1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>59493099999</td>
      <td>1998-01-01T02:00:00</td>
      <td>4</td>
      <td>FM-15</td>
      <td>ZGSZ</td>
      <td>V020</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0,999</td>
      <td>...</td>
      <td>NaN</td>
      <td>99999,9</td>
      <td>4</td>
      <td>+0240,1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>003500,1,N,1</td>
      <td>NaN</td>
      <td>110,1,N,0020,1</td>
      <td>240.1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>59493099999</td>
      <td>1998-01-01T03:00:00</td>
      <td>4</td>
      <td>SY-MT</td>
      <td>ZGSZ</td>
      <td>V020</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0,000</td>
      <td>...</td>
      <td>NaN</td>
      <td>10185,1</td>
      <td>4</td>
      <td>+0221,1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>011000,1,N,1</td>
      <td>NaN</td>
      <td>090,1,N,0020,1</td>
      <td>221.1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>59493099999</td>
      <td>1998-01-01T04:00:00</td>
      <td>4</td>
      <td>FM-15</td>
      <td>ZGSZ</td>
      <td>V020</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0,999</td>
      <td>...</td>
      <td>NaN</td>
      <td>99999,9</td>
      <td>4</td>
      <td>+0240,1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>005000,1,N,1</td>
      <td>NaN</td>
      <td>270,1,N,0030,1</td>
      <td>240.1</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 55 columns</p>
</div>




```python
# the next step is get the month and year 
Air_temp["Month"]=pd.to_datetime(Air_temp["DATE"]).dt.month
Air_temp["Year"]=pd.to_datetime(Air_temp["DATE"]).dt.year

```


```python
#compute the average temperature and using unstack() to spearate the information stored in groupby
Air_temp.groupby(["Month","Year"]).mean()["tem"].unstack().plot(figsize=(20,18),ylabel="The average temperature per month",fontsize=20)
```




    <AxesSubplot:xlabel='Month', ylabel='The average temperature per month'>




    
![png](output_16_1.png)
    


# ex3 Global collection of hurricanes


```python
df = pd.read_csv('ibtracs.ALL.list.v04r00.csv',
                 usecols=range(17),
                 skiprows=[1, 2], 
                 parse_dates=['ISO_TIME'],
                 na_values={"NAME":'NOT_NAMED',"WMO_WIND":" "}
```


      Input In [83]
        na_values={"NAME":'NOT_NAMED',"WMO_WIND":" "}
                                                     ^
    SyntaxError: unexpected EOF while parsing
    



```python
df["WMO_WIND"].astype("float")
df["ISO_TIME"]=pd.to_datetime(df["ISO_TIME"])
```


```python
#ex 3.1
df.sort_values("WMO_WIND",ascending=False).groupby("SID")["NAME"].head(10)
```




    665954    PATRICIA
    665952    PATRICIA
    665956    PATRICIA
    427636       ALLEN
    178212         NaN
                ...   
    707160        KARL
    707161        KARL
    707173         NaN
    707174         NaN
    707175         NaN
    Name: NAME, Length: 134350, dtype: object




```python
#ex 3.2
df.sort_values("WMO_WIND",ascending=False).head(20).plot(x="NAME",y="WMO_WIND",kind="bar",color="red")
```




    <AxesSubplot:xlabel='NAME'>




    
![png](output_21_1.png)
    



```python
#ex 3.3
df.groupby("BASIN").count().plot(kind="bar",figsize=(20,20),fontsize=18,stacked=True)
```




    <AxesSubplot:xlabel='BASIN'>




    
![png](output_22_1.png)
    



```python
#EX 3.4 make a hexbin plot od location
df.plot.hexbin(x="LAT",y="LON",gridsize=27,label="the location of datapoints")
```




    <AxesSubplot:xlabel='LAT', ylabel='LON'>




    
![png](output_23_1.png)
    



```python
#ex3.5 
# first, find typhoon manakhut in 2018

df["Year"]=pd.to_datetime(df["ISO_TIME"]).dt.year
df["Month"]=pd.to_datetime(df["ISO_TIME"]).dt.month
df["Day"]=pd.to_datetime(df["ISO_TIME"]).dt.day
df2=df.loc[ (df["NAME"]=="MANGKHUT") & (df["SEASON"]==2018) ]
```


```python
#then, print the scatter plot using mataploit
df2.plot.scatter(x="LAT",y="LON",color="DarkGreen")
```




    <AxesSubplot:xlabel='LAT', ylabel='LON'>




    
![png](output_25_1.png)
    



```python
#ex 3.6 using df3 to stand for the dataframe for the rest questions
df3=df.loc[((df["BASIN"]=="WP") | (df["BASIN"]=="EP"))& (df["SEASON"]>=1970)  ]
df3
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SID</th>
      <th>SEASON</th>
      <th>NUMBER</th>
      <th>BASIN</th>
      <th>SUBBASIN</th>
      <th>NAME</th>
      <th>ISO_TIME</th>
      <th>NATURE</th>
      <th>LAT</th>
      <th>LON</th>
      <th>WMO_WIND</th>
      <th>WMO_PRES</th>
      <th>WMO_AGENCY</th>
      <th>TRACK_TYPE</th>
      <th>DIST2LAND</th>
      <th>LANDFALL</th>
      <th>IFLAG</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>350393</th>
      <td>1970050N07151</td>
      <td>1970</td>
      <td>22</td>
      <td>WP</td>
      <td>MM</td>
      <td>NANCY</td>
      <td>1970-02-19 00:00:00</td>
      <td>TS</td>
      <td>7.00000</td>
      <td>151.400</td>
      <td>NaN</td>
      <td>1006.0</td>
      <td>tokyo</td>
      <td>main</td>
      <td>1088</td>
      <td>1088.0</td>
      <td>_OO___________</td>
    </tr>
    <tr>
      <th>350394</th>
      <td>1970050N07151</td>
      <td>1970</td>
      <td>22</td>
      <td>WP</td>
      <td>MM</td>
      <td>NANCY</td>
      <td>1970-02-19 03:00:00</td>
      <td>TS</td>
      <td>7.24752</td>
      <td>151.205</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>main</td>
      <td>1109</td>
      <td>1109.0</td>
      <td>_PP___________</td>
    </tr>
    <tr>
      <th>350395</th>
      <td>1970050N07151</td>
      <td>1970</td>
      <td>22</td>
      <td>WP</td>
      <td>MM</td>
      <td>NANCY</td>
      <td>1970-02-19 06:00:00</td>
      <td>TS</td>
      <td>7.50000</td>
      <td>151.000</td>
      <td>NaN</td>
      <td>1002.0</td>
      <td>tokyo</td>
      <td>main</td>
      <td>1143</td>
      <td>1143.0</td>
      <td>_OO___________</td>
    </tr>
    <tr>
      <th>350396</th>
      <td>1970050N07151</td>
      <td>1970</td>
      <td>22</td>
      <td>WP</td>
      <td>MM</td>
      <td>NANCY</td>
      <td>1970-02-19 09:00:00</td>
      <td>TS</td>
      <td>7.75747</td>
      <td>150.772</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>main</td>
      <td>1171</td>
      <td>1168.0</td>
      <td>_PP___________</td>
    </tr>
    <tr>
      <th>350397</th>
      <td>1970050N07151</td>
      <td>1970</td>
      <td>22</td>
      <td>WP</td>
      <td>MM</td>
      <td>NANCY</td>
      <td>1970-02-19 12:00:00</td>
      <td>TS</td>
      <td>8.00000</td>
      <td>150.500</td>
      <td>NaN</td>
      <td>998.0</td>
      <td>tokyo</td>
      <td>main</td>
      <td>1182</td>
      <td>1179.0</td>
      <td>_OO___________</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>707084</th>
      <td>2022275N10316</td>
      <td>2022</td>
      <td>76</td>
      <td>EP</td>
      <td>MM</td>
      <td>JULIA</td>
      <td>2022-10-10 15:00:00</td>
      <td>TS</td>
      <td>13.99570</td>
      <td>-90.294</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PROVISIONAL</td>
      <td>0</td>
      <td>0.0</td>
      <td>P_____________</td>
    </tr>
    <tr>
      <th>707085</th>
      <td>2022275N10316</td>
      <td>2022</td>
      <td>76</td>
      <td>EP</td>
      <td>MM</td>
      <td>JULIA</td>
      <td>2022-10-10 18:00:00</td>
      <td>NR</td>
      <td>14.50000</td>
      <td>-91.000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PROVISIONAL</td>
      <td>0</td>
      <td>NaN</td>
      <td>O_____________</td>
    </tr>
    <tr>
      <th>707173</th>
      <td>2022286N15151</td>
      <td>2022</td>
      <td>80</td>
      <td>WP</td>
      <td>MM</td>
      <td>NaN</td>
      <td>2022-10-12 12:00:00</td>
      <td>NR</td>
      <td>15.20000</td>
      <td>151.300</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PROVISIONAL</td>
      <td>1985</td>
      <td>1974.0</td>
      <td>O_____________</td>
    </tr>
    <tr>
      <th>707174</th>
      <td>2022286N15151</td>
      <td>2022</td>
      <td>80</td>
      <td>WP</td>
      <td>MM</td>
      <td>NaN</td>
      <td>2022-10-12 15:00:00</td>
      <td>NR</td>
      <td>15.05000</td>
      <td>151.325</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PROVISIONAL</td>
      <td>1974</td>
      <td>1952.0</td>
      <td>P_____________</td>
    </tr>
    <tr>
      <th>707175</th>
      <td>2022286N15151</td>
      <td>2022</td>
      <td>80</td>
      <td>WP</td>
      <td>MM</td>
      <td>NaN</td>
      <td>2022-10-12 18:00:00</td>
      <td>NR</td>
      <td>14.90000</td>
      <td>151.350</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PROVISIONAL</td>
      <td>1954</td>
      <td>NaN</td>
      <td>O_____________</td>
    </tr>
  </tbody>
</table>
<p>176352 rows × 17 columns</p>
</div>




```python
#3.7 plot datapoints per day
df3["Date"]=pd.to_datetime(df3["ISO_TIME"]).dt.floor("d")
# plot the numbers
df3.groupby("Date")["LAT"].count().plot(figsize=(30,30),fontsize=18,stacked=True,kind="hist")
```

    C:\Users\Administrator\AppData\Local\Temp\ipykernel_11040\2578935874.py:2: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df3["Date"]=pd.to_datetime(df3["ISO_TIME"]).dt.floor("d")
    




    <AxesSubplot:ylabel='Frequency'>




    
![png](output_27_2.png)
    



```python
#3.8
df3["Day_of_year"]=pd.to_datetime(df3["ISO_TIME"]).dt.day_of_year
```

    C:\Users\Administrator\AppData\Local\Temp\ipykernel_11040\736370400.py:2: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df3["Day_of_year"]=pd.to_datetime(df3["ISO_TIME"]).dt.day_of_year
    


```python
df3.groupby(["SEASON","Day_of_year"])["SID"].count()
```




    SEASON  Day_of_year
    2022    179             7
            180             2
            181            10
            182            16
            183            17
                           ..
            277             9
            278             7
            282             1
            283             7
            285             3
    Name: SID, Length: 100, dtype: int64




```python
#3.9 the anomaly of daily counts
df4=df3.groupby(["SEASON","Day_of_year"])["SID"].count()-df3.groupby(["SEASON","Day_of_year"])["SID"].count().mean()
df4.plot(label="the anomaly of daily counts ",fontsize=18,figsize=(20,20))
```




    <AxesSubplot:xlabel='SEASON,Day_of_year'>




    
![png](output_30_1.png)
    



```python
#3.10 resample the timerseries at annual 
df5=df3.groupby("SEASON")["SID"].count()-df3.groupby("SEASON")["SID"].count().mean()
df5.plot()
# so in 1992 or 1993 there are most anomalous hurricane activity
```




    <AxesSubplot:xlabel='SEASON'>




    
![png](output_31_1.png)
    


## Ex4 explore a data set 


```python
# I dowload cfc-11 in Advanced Global Atmospheric Gases Experiment (AGAGE) as my database. Before loading it, i deal with the flie and fliter
# some information.
#4.1 load a file 

cfc11_data=pd.read_excel("cfc_11.xlsx")
cfc11_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>year</th>
      <th>annual Production</th>
      <th>annaual released</th>
      <th>Unnamed: 3</th>
      <th>total Production</th>
      <th>total Released</th>
      <th>total Unreleased</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1931</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1932</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1933</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1934</td>
      <td>0.045675</td>
      <td>0.003825</td>
      <td>NaN</td>
      <td>0.045675</td>
      <td>0.003825</td>
      <td>0.041850</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1935</td>
      <td>0.045675</td>
      <td>0.007875</td>
      <td>NaN</td>
      <td>0.091350</td>
      <td>0.011700</td>
      <td>0.079650</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>68</th>
      <td>1999</td>
      <td>13.064065</td>
      <td>48.271442</td>
      <td>NaN</td>
      <td>8814.381800</td>
      <td>7867.006216</td>
      <td>947.375584</td>
    </tr>
    <tr>
      <th>69</th>
      <td>2000</td>
      <td>10.048500</td>
      <td>44.775559</td>
      <td>NaN</td>
      <td>8824.430300</td>
      <td>7911.781776</td>
      <td>912.648524</td>
    </tr>
    <tr>
      <th>70</th>
      <td>2001</td>
      <td>8.435665</td>
      <td>41.129395</td>
      <td>NaN</td>
      <td>8832.865965</td>
      <td>7952.911170</td>
      <td>879.954795</td>
    </tr>
    <tr>
      <th>71</th>
      <td>2002</td>
      <td>6.896925</td>
      <td>37.386376</td>
      <td>NaN</td>
      <td>8839.762890</td>
      <td>7990.297546</td>
      <td>849.465344</td>
    </tr>
    <tr>
      <th>72</th>
      <td>2003</td>
      <td>3.192175</td>
      <td>34.500977</td>
      <td>NaN</td>
      <td>8842.955065</td>
      <td>8024.798523</td>
      <td>818.156542</td>
    </tr>
  </tbody>
</table>
<p>73 rows × 7 columns</p>
</div>




```python
#4.2 plot the figure for annual production and annual released
cfc11_data.plot(x="year",y=["annual Production","annaual released"])
```




    <AxesSubplot:xlabel='year'>




    
![png](output_34_1.png)
    



```python
#4.3 
# find the max of annual production 
cfc11_data["annual Production"].max()
# find the max of increaing of cfc11 per year
(cfc11_data["annual Production"]-cfc11_data["annaual released"]).abs().max()
```




    77.18835053982389




```python
# the describe of data
cfc11_data.describe()
# check the data unequal to 0 
cfc11_data.loc[(cfc11_data["annual Production"])!=0|(cfc11_data["annaual released"]!=0)].count()
#  check the year with biggest released
cfc11_data.loc[cfc11_data["annaual released"]==cfc11_data["annaual released"].max()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>year</th>
      <th>annual Production</th>
      <th>annaual released</th>
      <th>Unnamed: 3</th>
      <th>total Production</th>
      <th>total Released</th>
      <th>total Unreleased</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>43</th>
      <td>1974</td>
      <td>375.26986</td>
      <td>321.433165</td>
      <td>NaN</td>
      <td>3025.50185</td>
      <td>2553.958263</td>
      <td>471.543587</td>
    </tr>
  </tbody>
</table>
</div>


